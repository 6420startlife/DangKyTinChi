package com.ptithcm.dangkytinchi.interfaces;

import retrofit2.Call;
import retrofit2.http.GET;
import retrofit2.http.Query;

public interface ApiInterface {
    @GET("Login/Login")
    Call<String> login(@Query("username") String username, @Query("pass") String pass);
}
