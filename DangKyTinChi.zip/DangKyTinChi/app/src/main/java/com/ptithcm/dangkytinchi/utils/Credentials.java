package com.ptithcm.dangkytinchi.utils;

public class Credentials {
    public static final String BASE_URL = "http://khanhduy1751-001-site1.ctempurl.com/api/";
    public static final int STATUS_SUCCESS = 200;
    public static final String ROLE_SV = "SINHVIEN";
}
