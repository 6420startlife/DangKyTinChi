package com.ptithcm.dangkytinchi.utils;

public class Regex {
    public static final String regexMaSV = "^[NnCc]{1}\\d{2}[DdCcNnAaTtQqVvPpKkSs]{4}\\d{3}$";
}
