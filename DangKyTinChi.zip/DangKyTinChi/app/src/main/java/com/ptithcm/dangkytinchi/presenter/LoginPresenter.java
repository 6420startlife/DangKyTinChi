package com.ptithcm.dangkytinchi.presenter;


import androidx.lifecycle.Observer;

import com.ptithcm.dangkytinchi.activities.LoginActivity;
import com.ptithcm.dangkytinchi.interfaces.LoginInterface;
import com.ptithcm.dangkytinchi.models.User;
import com.ptithcm.dangkytinchi.repositories.LoginRepository;

public class LoginPresenter{
    private LoginInterface mLoginInterface;
    private LoginActivity context;

    public LoginPresenter(LoginInterface mLoginInterface, LoginActivity context) {
        this.mLoginInterface = mLoginInterface;
        this.context = context;
    }

    public void login(User user){
        if(user.isValidUsername() && user.isValidPassword()){
            checkLogin(user);
            return;
        }
        if(!user.isValidUsername()) {
            mLoginInterface.invalidUsername();
        }
        if(!user.isValidPassword()) {
            mLoginInterface.invalidPassword();
        }
    }

    private void checkLogin(User user) {
        LoginRepository loginRepository = LoginRepository.getInstance();
        loginRepository.login(user);
        loginRepository.getIsUpdating().observe(context, new Observer<Boolean>() {
            @Override
            public void onChanged(Boolean aBoolean) {
                if(aBoolean) {
                    mLoginInterface.turnOnLoading();
                }else {
                    mLoginInterface.turnOffLoading();
                }
            }
        });
        loginRepository.getIsSuccess().observe(context, new Observer<Boolean>() {
            @Override
            public void onChanged(Boolean aBoolean) {
                if(aBoolean) {
                    mLoginInterface.loginSuccess();
                    return;
                }else {
                    mLoginInterface.loginFailed();
                }
            }
        });
    }
}
