package com.ptithcm.dangkytinchi.repositories;

import static com.ptithcm.dangkytinchi.utils.Credentials.ROLE_SV;
import static com.ptithcm.dangkytinchi.utils.Credentials.STATUS_SUCCESS;

import android.util.Log;

import androidx.lifecycle.MutableLiveData;

import com.ptithcm.dangkytinchi.models.User;
import com.ptithcm.dangkytinchi.services.ApiService;

import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class LoginRepository {
    private MutableLiveData<Boolean> isSuccess;
    private MutableLiveData<Boolean> isUpdating;

    public static LoginRepository instance;

    public static LoginRepository getInstance() {
        if (instance == null) {
            return instance = new LoginRepository();
        }
        return instance;
    }

    public MutableLiveData<Boolean> getIsSuccess() {
        return isSuccess;
    }

    public void setIsSuccess(MutableLiveData<Boolean> isSuccess) {
        this.isSuccess = isSuccess;
    }

    public MutableLiveData<Boolean> getIsUpdating() {
        return isUpdating;
    }

    public void setIsUpdating(MutableLiveData<Boolean> isUpdating) {
        this.isUpdating = isUpdating;
    }


    public LoginRepository() {
        isSuccess = new MutableLiveData<>();
        isUpdating = new MutableLiveData<>();
        isUpdating.setValue(false);
    }

    public void login(User user) {
        isUpdating.setValue(true);
        ApiService.getApi().login(user.getUsername(),user.getPassword()).enqueue(new Callback<String>() {
            @Override
            public void onResponse(Call<String> call, Response<String> response) {
                if(!response.isSuccessful()){
                    isSuccess.setValue(false);
                    isUpdating.setValue(false);
                    return;
                }
                if(response.code() != STATUS_SUCCESS) {
                    isSuccess.setValue(false);
                    isUpdating.setValue(false);
                    Log.e("ErrorApi", "Đã vào response code khác 200");
                    return;
                }
                if(!response.body().toString().equalsIgnoreCase(ROLE_SV)){
                    isSuccess.setValue(false);
                    isUpdating.setValue(false);
                    Log.e("ErrorApi", "Đã vào response value không bằng sinh viên");
                    return;
                }
                isSuccess.setValue(true);
                isUpdating.setValue(false);
                Log.e("ErrorApi", "Đã vào response và kết quả đúng");
            }

            @Override
            public void onFailure(Call<String> call, Throwable t) {
                isSuccess.setValue(false);
                isUpdating.setValue(false);
                Log.e("ErrorApi", t.getMessage());
            }
        });
    }
}
